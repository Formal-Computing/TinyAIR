; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(assert
 (let (($x15 (and true (not (= 0 n)))))
(let (($x8 (and (<= 0 n))))
(let (($x17 (and $x8 $x15)))
(let (($x24 (=> $x17 (< (- n 1) n))))
(not $x24))))))
(check-sat)
