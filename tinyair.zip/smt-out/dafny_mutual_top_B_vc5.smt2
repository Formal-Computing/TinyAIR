; benchmark generated from python API
(set-info :status unknown)
(declare-fun A_result_!1 () Int)
(declare-fun x () Int)
(assert
 (let (($x8 (and (<= 0 x))))
(let (($x46 (and $x8 (=> (and true (and (distinct 0 x) true)) (= 0 A_result_!1)))))
(let (($x48 (=> $x46 (= 0 (ite (and (distinct 0 x) true) A_result_!1 0)))))
(not $x48)))))
(check-sat)
