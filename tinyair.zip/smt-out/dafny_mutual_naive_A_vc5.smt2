; benchmark generated from python API
(set-info :status unknown)
(declare-fun B_result_!0 () Int)
(declare-fun x () Int)
(assert
 (let (($x18 (= 0 B_result_!0)))
(let (($x21 (=> (and (and (<= 0 x)) (=> true $x18)) $x18)))
(not $x21))))
(check-sat)
