; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(declare-fun fib_result_!0 () Int)
(assert
 (let (($x14 (and true (not (>= 1 n)))))
(let (($x27 (=> $x14 (<= 0 fib_result_!0))))
(let (($x8 (and (<= 0 n))))
(let (($x30 (and $x8 $x27 $x14)))
(let (($x37 (=> $x30 (< (- n 2) n))))
(not $x37)))))))
(check-sat)
