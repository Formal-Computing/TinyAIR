; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(assert
 (let (($x10 (>= n 0)))
(let (($x8 (and (<= 0 n))))
(let (($x14 (=> $x8 $x10)))
(not $x14)))))
(check-sat)
