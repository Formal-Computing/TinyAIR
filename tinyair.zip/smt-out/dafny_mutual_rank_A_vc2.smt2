; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x8 (and (<= 0 x))))
(let (($x13 (and $x8 true)))
(let (($x14 (=> $x13 $x8)))
(not $x14)))))
(check-sat)
