; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x27 (and (distinct 0 x) true)))
(let (($x28 (and true $x27)))
(let (($x8 (and (<= 0 x))))
(let (($x31 (and $x8 $x28)))
(let (($x36 (=> $x31 (>= (- x 1) 0))))
(not $x36)))))))
(check-sat)
