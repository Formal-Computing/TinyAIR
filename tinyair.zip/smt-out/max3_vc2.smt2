; benchmark generated from python API
(set-info :status unknown)
(declare-fun b () Int)
(declare-fun c () Int)
(declare-fun a () Int)
(assert
 (let ((?x13 (ite (>= a b) (ite (>= a c) a c) (ite (>= b c) b c))))
(let (($x14 (and true)))
(let (($x18 (=> $x14 (>= ?x13 b))))
(not $x18)))))
(check-sat)
