; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(declare-fun m () Int)
(assert
 (let (($x12 (>= n 0)))
(let (($x8 (<= 0 n)))
(let (($x10 (and $x8 (<= 0 m))))
(let (($x13 (=> $x10 $x12)))
(not $x13))))))
(check-sat)
