; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(assert
 (let (($x26 (and (and true (= n n)) (and (< 0 0) (>= 0 0)))))
(let (($x14 (and true (not (= 0 n)))))
(let (($x8 (and (<= 0 n))))
(let (($x15 (and $x8 $x14)))
(let (($x27 (=> $x15 (or (and true (and (< n n) (>= n 0))) $x26))))
(not $x27)))))))
(check-sat)
