; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x8 (and (<= 0 x))))
(let (($x12 (and $x8 true)))
(let (($x16 (=> $x12 (< x x))))
(not $x16)))))
(check-sat)
