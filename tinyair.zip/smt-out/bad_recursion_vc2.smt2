; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(assert
 (let (($x8 (and (<= 0 n))))
(let (($x14 (and true (not (= 0 n)))))
(let (($x15 (and $x8 $x14)))
(let (($x16 (=> $x15 $x8)))
(not $x16))))))
(check-sat)
