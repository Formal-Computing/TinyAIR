; benchmark generated from python API
(set-info :status unknown)
(declare-fun b () Int)
(declare-fun a () Int)
(assert
 (let (($x15 (and (>= (ite (>= a b) a b) a) (>= (ite (>= a b) a b) b))))
(let (($x12 (and (and true))))
(let (($x11 (=> $x12 $x15)))
(not $x11)))))
(check-sat)
