; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x9 (=> (and and true) and)))
(not $x9)))
(check-sat)
