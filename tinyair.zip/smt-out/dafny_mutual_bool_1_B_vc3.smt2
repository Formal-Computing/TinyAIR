; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x30 (and (distinct 0 x) true)))
(let (($x31 (and true $x30)))
(let (($x8 (and (<= 0 x))))
(let (($x34 (and $x8 $x31)))
(let (($x39 (=> $x34 (>= (- x 1) 0))))
(not $x39)))))))
(check-sat)
