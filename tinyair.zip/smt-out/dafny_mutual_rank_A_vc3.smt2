; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x10 (>= x 0)))
(let (($x8 (and (<= 0 x))))
(let (($x13 (and $x8 true)))
(let (($x15 (=> $x13 $x10)))
(not $x15))))))
(check-sat)
