; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x27 (and (distinct 0 x) true)))
(let (($x28 (and true $x27)))
(let (($x8 (and (<= 0 x))))
(let (($x31 (and $x8 $x28)))
(let (($x40 (=> $x31 (or (and true (and (< (- x 1) x) (>= x 0)))))))
(not $x40)))))))
(check-sat)
