; benchmark generated from python API
(set-info :status unknown)
(declare-fun stuck_result_!0 () Int)
(declare-fun n () Int)
(assert
 (let (($x8 (and (<= 0 n))))
(let (($x33 (and $x8 (=> (and true (not (= 0 n))) (= 0 stuck_result_!0)))))
(let (($x35 (=> $x33 (= 0 (ite (= 0 n) 0 stuck_result_!0)))))
(not $x35)))))
(check-sat)
