; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(assert
 (let (($x12 (and true (not (= 0 n)))))
(let (($x8 (and (<= 0 n))))
(let (($x18 (and $x8 $x12)))
(let (($x25 (=> $x18 (< (- n 1) n))))
(not $x25))))))
(check-sat)
