; benchmark generated from python API
(set-info :status unknown)
(declare-fun c () Int)
(declare-fun b () Int)
(declare-fun a () Int)
(assert
 (let ((?x13 (ite (>= a b) (ite (>= a c) a c) (ite (>= b c) b c))))
(let (($x14 (and true)))
(let (($x26 (=> $x14 (or (or (= ?x13 a) (= ?x13 b)) (= ?x13 c)))))
(not $x26)))))
(check-sat)
