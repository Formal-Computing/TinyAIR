; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x32 (and (distinct 0 x) true)))
(let (($x33 (and true $x32)))
(let (($x8 (and (<= 0 x))))
(let (($x35 (and $x8 $x33)))
(let (($x40 (=> $x35 (>= (- x 1) 0))))
(not $x40)))))))
(check-sat)
