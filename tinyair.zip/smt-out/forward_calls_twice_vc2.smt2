; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun inc_result_!0 () Int)
(assert
 (let (($x17 (=> (and and (=> true (= inc_result_!0 (+ x 1))) true) and)))
(not $x17)))
(check-sat)
