; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(assert
 (let (($x14 (and true (not (>= 1 n)))))
(let (($x8 (and (<= 0 n))))
(let (($x17 (and $x8 $x14)))
(let (($x20 (=> $x17 (and (<= 0 (- n 1))))))
(not $x20))))))
(check-sat)
