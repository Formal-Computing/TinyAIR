; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(declare-fun oddCount_result_!0 () Int)
(assert
 (let (($x14 (and true (not (= 0 n)))))
(let (($x8 (and (<= 0 n))))
(let (($x32 (=> (and $x8 (=> $x14 (= oddCount_result_!0 (- n 1)))) (= (ite (= 0 n) 0 (+ 1 oddCount_result_!0)) n))))
(not $x32)))))
(check-sat)
