; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x20 (or (and true (and (< x x) (>= x 0))) (and true (= x x)))))
(let (($x8 (and (<= 0 x))))
(let (($x12 (and $x8 true)))
(let (($x21 (=> $x12 $x20)))
(not $x21))))))
(check-sat)
