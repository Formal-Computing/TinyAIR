; benchmark generated from python API
(set-info :status unknown)
(declare-fun B_result_!0 () Int)
(declare-fun x () Int)
(assert
 (let (($x28 (= 0 B_result_!0)))
(let (($x31 (=> (and (and (<= 0 x)) (=> true $x28)) $x28)))
(not $x31))))
(check-sat)
