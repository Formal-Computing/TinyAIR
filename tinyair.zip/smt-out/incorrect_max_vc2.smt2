; benchmark generated from python API
(set-info :status unknown)
(declare-fun b () Int)
(declare-fun a () Int)
(assert
 (let (($x20 (or (= (ite (>= a b) b a) a) (= (ite (>= a b) b a) b))))
(let (($x12 (and (and true))))
(let (($x17 (=> $x12 $x20)))
(not $x17)))))
(check-sat)
