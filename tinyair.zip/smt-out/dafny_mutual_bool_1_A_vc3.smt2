; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x10 (>= x 0)))
(let (($x8 (and (<= 0 x))))
(let (($x12 (and $x8 true)))
(let (($x14 (=> $x12 $x10)))
(not $x14))))))
(check-sat)
