; benchmark generated from python API
(set-info :status unknown)
(declare-fun c () Int)
(declare-fun b () Int)
(declare-fun a () Int)
(assert
 (let ((?x13 (ite (>= a b) (ite (>= a c) a c) (ite (>= b c) b c))))
(let (($x14 (and true)))
(let (($x20 (=> $x14 (>= ?x13 c))))
(not $x20)))))
(check-sat)
