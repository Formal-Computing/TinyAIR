; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x24 (and (and true (= x x)) (and (< 0 1) (>= 1 0)))))
(let (($x8 (and (<= 0 x))))
(let (($x13 (and $x8 true)))
(let (($x25 (=> $x13 (or (and true (and (< x x) (>= x 0))) $x24))))
(not $x25))))))
(check-sat)
