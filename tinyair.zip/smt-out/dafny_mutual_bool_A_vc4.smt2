; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x25 (or (and true (and (< x x) (>= x 0))) (and (and true (= x x)) (and (not false) true)))))
(let (($x8 (and (<= 0 x))))
(let (($x12 (and $x8 true)))
(let (($x23 (=> $x12 $x25)))
(not $x23))))))
(check-sat)
