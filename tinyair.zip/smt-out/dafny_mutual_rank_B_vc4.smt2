; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x49 (and (and true (= (- x 1) x)) (and (< 1 0) (>= 0 0)))))
(let (($x32 (and (distinct 0 x) true)))
(let (($x33 (and true $x32)))
(let (($x8 (and (<= 0 x))))
(let (($x35 (and $x8 $x33)))
(let (($x50 (=> $x35 (or (and true (and (< (- x 1) x) (>= x 0))) $x49))))
(not $x50))))))))
(check-sat)
