; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x12 (and (and true))))
(let (($x11 (=> $x12 (<= 0 (ite (<= 0 x) x (- x))))))
(not $x11))))
(check-sat)
