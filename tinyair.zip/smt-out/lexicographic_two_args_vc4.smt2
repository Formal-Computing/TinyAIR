; benchmark generated from python API
(set-info :status unknown)
(declare-fun m () Int)
(declare-fun n () Int)
(assert
 (let (($x34 (and (and true (= n n)) (and (< (- m 1) m) (>= m 0)))))
(let (($x18 (and (and true (= 0 n)) (not (= 0 m)))))
(let (($x8 (<= 0 n)))
(let (($x10 (and $x8 (<= 0 m))))
(let (($x21 (and $x10 $x18)))
(let (($x35 (=> $x21 (or (and true (and (< n n) (>= n 0))) $x34))))
(not $x35))))))))
(check-sat)
