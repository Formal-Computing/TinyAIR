; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(declare-fun evenCount_result_!1 () Int)
(assert
 (let (($x14 (and true (not (= 0 n)))))
(let (($x8 (and (<= 0 n))))
(let (($x40 (=> (and $x8 (=> $x14 (= evenCount_result_!1 (- n 1)))) (= (ite (= 0 n) 0 (+ 1 evenCount_result_!1)) n))))
(not $x40)))))
(check-sat)
