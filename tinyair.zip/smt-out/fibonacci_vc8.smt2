; benchmark generated from python API
(set-info :status unknown)
(declare-fun fib_result_!1 () Int)
(declare-fun fib_result_!0 () Int)
(declare-fun n () Int)
(assert
 (let (($x14 (and true (not (>= 1 n)))))
(let (($x27 (=> $x14 (<= 0 fib_result_!0))))
(let (($x8 (and (<= 0 n))))
(let (($x45 (=> (and $x8 $x27 (=> $x14 (<= 0 fib_result_!1))) (<= 0 (ite (>= 1 n) n (+ fib_result_!0 fib_result_!1))))))
(not $x45))))))
(check-sat)
