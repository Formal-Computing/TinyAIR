; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(assert
 (let (($x10 (>= n 0)))
(let (($x14 (and true (not (= 0 n)))))
(let (($x8 (and (<= 0 n))))
(let (($x15 (and $x8 $x14)))
(let (($x17 (=> $x15 $x10)))
(not $x17)))))))
(check-sat)
