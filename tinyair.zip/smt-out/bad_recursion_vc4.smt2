; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(assert
 (let (($x14 (and true (not (= 0 n)))))
(let (($x8 (and (<= 0 n))))
(let (($x15 (and $x8 $x14)))
(let (($x19 (=> $x15 (< n n))))
(not $x19))))))
(check-sat)
