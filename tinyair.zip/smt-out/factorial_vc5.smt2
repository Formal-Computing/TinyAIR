; benchmark generated from python API
(set-info :status unknown)
(declare-fun factorial_result_!0 () Int)
(declare-fun n () Int)
(assert
 (let (($x15 (and true (not (= 0 n)))))
(let (($x8 (and (<= 0 n))))
(let (($x32 (and $x8 (=> $x15 (<= 1 factorial_result_!0)) (=> $x15 (>= factorial_result_!0 (- n 1))))))
(let (($x34 (=> $x32 (<= 1 (ite (= 0 n) 1 (* n factorial_result_!0))))))
(not $x34))))))
(check-sat)
