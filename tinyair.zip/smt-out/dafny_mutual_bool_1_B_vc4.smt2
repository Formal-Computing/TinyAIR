; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x50 (or (and true (and (< (- x 1) x) (>= x 0))) (and (and true (= (- x 1) x)) (and (not false) true)))))
(let (($x30 (and (distinct 0 x) true)))
(let (($x31 (and true $x30)))
(let (($x8 (and (<= 0 x))))
(let (($x34 (and $x8 $x31)))
(let (($x48 (=> $x34 $x50)))
(not $x48))))))))
(check-sat)
