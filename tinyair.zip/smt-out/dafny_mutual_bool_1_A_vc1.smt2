; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x10 (>= x 0)))
(let (($x8 (and (<= 0 x))))
(let (($x11 (=> $x8 $x10)))
(not $x11)))))
(check-sat)
