; benchmark generated from python API
(set-info :status unknown)
(declare-fun a () Int)
(declare-fun c () Int)
(declare-fun b () Int)
(assert
 (let ((?x13 (ite (>= a b) (ite (>= a c) a c) (ite (>= b c) b c))))
(let (($x14 (and true)))
(let (($x16 (=> $x14 (>= ?x13 a))))
(not $x16)))))
(check-sat)
