; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x8 (and (<= 0 x))))
(let (($x12 (and $x8 true)))
(let (($x13 (=> $x12 $x8)))
(not $x13)))))
(check-sat)
