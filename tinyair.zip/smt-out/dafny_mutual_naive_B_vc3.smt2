; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x22 (and (distinct 0 x) true)))
(let (($x23 (and true $x22)))
(let (($x8 (and (<= 0 x))))
(let (($x26 (and $x8 $x23)))
(let (($x31 (=> $x26 (>= (- x 1) 0))))
(not $x31)))))))
(check-sat)
