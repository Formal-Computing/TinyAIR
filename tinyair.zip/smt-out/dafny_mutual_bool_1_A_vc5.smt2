; benchmark generated from python API
(set-info :status unknown)
(declare-fun B_result_!0 () Int)
(declare-fun x () Int)
(assert
 (let (($x26 (= 0 B_result_!0)))
(let (($x29 (=> (and (and (<= 0 x)) (=> true $x26)) $x26)))
(not $x29))))
(check-sat)
