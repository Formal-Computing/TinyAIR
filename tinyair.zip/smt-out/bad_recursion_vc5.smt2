; benchmark generated from python API
(set-info :status unknown)
(declare-fun loop_result_!0 () Int)
(declare-fun n () Int)
(assert
 (let (($x8 (and (<= 0 n))))
(let (($x24 (and $x8 (=> (and true (not (= 0 n))) (= 0 loop_result_!0)))))
(let (($x26 (=> $x24 (= 0 (ite (= 0 n) 0 loop_result_!0)))))
(not $x26)))))
(check-sat)
