; benchmark generated from python API
(set-info :status unknown)
(declare-fun n () Int)
(assert
 (let (($x12 (>= n 0)))
(let (($x8 (and (<= 0 n))))
(let (($x11 (=> $x8 $x12)))
(not $x11)))))
(check-sat)
