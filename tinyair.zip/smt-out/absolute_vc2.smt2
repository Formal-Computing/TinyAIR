; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x19 (or (= (ite (<= 0 x) x (- x)) x) (= (ite (<= 0 x) x (- x)) (- x)))))
(let (($x12 (and (and true))))
(let (($x16 (=> $x12 $x19)))
(not $x16)))))
(check-sat)
