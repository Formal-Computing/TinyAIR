; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (let (($x28 (=> (and and) (= (+ x 1) (+ x 1)))))
(not $x28)))
(check-sat)
