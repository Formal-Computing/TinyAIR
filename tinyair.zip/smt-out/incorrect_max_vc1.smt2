; benchmark generated from python API
(set-info :status unknown)
(declare-fun b () Int)
(declare-fun a () Int)
(assert
 (let (($x15 (and (>= (ite (>= a b) b a) a) (>= (ite (>= a b) b a) b))))
(let (($x12 (and (and true))))
(let (($x11 (=> $x12 $x15)))
(not $x11)))))
(check-sat)
