; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun inc_result_!1 () Int)
(declare-fun inc_result_!0 () Int)
(assert
 (let (($x15 (=> true (= inc_result_!0 (+ x 1)))))
(let (($x22 (and and $x15 (=> true (= inc_result_!1 (+ inc_result_!0 1))))))
(let (($x25 (=> $x22 (= inc_result_!1 (+ x 2)))))
(not $x25)))))
(check-sat)
