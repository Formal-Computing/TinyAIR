; benchmark generated from python API
(set-info :status unknown)
(declare-fun B_result_!0 () Int)
(declare-fun x () Int)
(assert
 (let (($x23 (= 0 B_result_!0)))
(let (($x26 (=> (and (and (<= 0 x)) (=> true $x23)) $x23)))
(not $x26))))
(check-sat)
