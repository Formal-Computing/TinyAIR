; benchmark generated from python API
(set-info :status unknown)
(declare-fun m () Int)
(declare-fun n () Int)
(assert
 (let (($x18 (and (and true (= 0 n)) (not (= 0 m)))))
(let (($x8 (<= 0 n)))
(let (($x10 (and $x8 (<= 0 m))))
(let (($x21 (and $x10 $x18)))
(let (($x24 (=> $x21 (and $x8 (<= 0 (- m 1))))))
(not $x24)))))))
(check-sat)
