; RB insertion n=3, color=(False, (False, None, None), (False, None, None)), path=2
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x30 (or $x48 $x15 $x91)))
(let (($x41 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x108 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x111 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x67 (and $x111 $x108 $x41 $x111 $x108 $x41 (= $x30 (or $x48 $x15 $x91 (= inserted inserted))))))
(let (($x130 (and true true (= 0 0))))
(let (($x12 (and $x130 $x130 (= (+ 0 1) (+ 0 1)) (< k0 k1) (< k1 k2))))
(let (($x123 (and $x12 $x67 true)))
(let (($x54 (=> (and $x12 (and (< inserted k1) $x48)) $x123)))
(not $x54))))))))))))))
(check-sat)
