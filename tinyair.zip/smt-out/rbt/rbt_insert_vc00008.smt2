; RB insertion n=2, color=(False, None, (False, None, None)), path=3
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x31 (= (or (= inserted k0) (= inserted k1)) (or (= inserted k0) (= inserted k1) (= inserted inserted)))))
(let (($x71 (= (or (= k1 k0) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x17 (= (or (= k0 k0) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x52 (and true (and true true (= 0 0)) (= 0 (+ 0 1)) (< k0 k1))))
(let (($x72 (and $x52 (and $x17 $x71 $x17 $x71 $x31) true)))
(let (($x69 (=> (and $x52 (and (> inserted k0) (= inserted k1))) $x72)))
(not $x69))))))))
(check-sat)
