; RB insertion n=2, color=(False, (True, None, None), None), path=3
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x67 (or (= inserted k0) (= inserted k1) (= inserted inserted))))
(let (($x102 (= $x67 $x67)))
(let (($x42 (or (= k1 k0) (= k1 k1) (= k1 inserted))))
(let (($x19 (= $x42 $x42)))
(let (($x16 (or (= k0 k0) (= k0 k1) (= k0 inserted))))
(let (($x73 (= $x16 $x16)))
(let (($x25 (< k0 k1)))
(let (($x54 (and true true (= 0 0) true)))
(let (($x62 (and $x54 $x54 (= (+ 0 0) (+ 0 0)) $x25 (< k1 inserted))))
(let (($x55 (and $x62 (and $x73 $x19 $x73 $x19 $x102 $x102) true)))
(let (($x82 (and (> inserted k1) true)))
(let (($x77 (and $x54 true (= 0 (+ 0 0)) $x25)))
(let (($x58 (=> (and $x77 $x82) $x55)))
(not $x58)))))))))))))))
(check-sat)
