; RB insertion n=2, color=(False, (False, None, None), None), path=1
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x22 (= (or (= inserted k0) (= inserted inserted) (= inserted k1)) (or (= inserted k0) (= inserted k1) (= inserted inserted)))))
(let (($x53 (= (or (= k1 k0) (= k1 inserted) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x88 (= (or (= k0 k0) (= k0 inserted) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x66 (< inserted k1)))
(let (($x25 (< k0 k1)))
(let ((?x100 (+ 0 1)))
(let (($x40 (= 0 ?x100)))
(let (($x21 (and true (and true true (= 0 0) true) (= 0 (+ 0 0)) (< k0 inserted))))
(let (($x84 (and $x21 true $x40 $x25 $x66)))
(let (($x20 (and $x84 (and $x88 $x53 $x88 $x22 $x53 $x22) true)))
(let (($x78 (and (> inserted k0) true)))
(let (($x72 (and $x66 $x78)))
(let (($x68 (and (and true true (= 0 0)) true $x40 $x25)))
(let (($x102 (=> (and $x68 $x72) $x20)))
(not $x102))))))))))))))))
(check-sat)
