; RB insertion n=3, color=(False, (True, (True, None, None), None), None), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x127 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x117 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x131 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x19 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x72 (and (and true true (= 0 0) true) true (= 0 (+ 0 0)) (< k0 k1) false)))
(let (($x135 (and $x72 true (= 0 (+ (+ 0 0) 0)) (< k0 k2) (< k1 k2))))
(let (($x70 (and $x135 (and $x19 $x131 $x117 $x19 $x131 $x117 $x127) true)))
(let (($x122 (=> (and $x135 $x91) $x70)))
(not $x122)))))))))))))
(check-sat)
