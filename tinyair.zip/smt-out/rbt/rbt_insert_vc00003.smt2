; RB insertion n=1, color=(False, None, None), path=1
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k0 () Int)
(assert
 (let (($x50 (or (= inserted k0) (= inserted inserted))))
(let (($x62 (= $x50 $x50)))
(let (($x46 (or (= k0 k0) (= k0 inserted))))
(let (($x43 (= $x46 $x46)))
(let (($x60 (and true (and true true (= 0 0) true) (= 0 (+ 0 0)) (< k0 inserted))))
(let (($x64 (and $x60 (and $x43 $x43 $x62 $x62) true)))
(let (($x58 (and (> inserted k0) true)))
(let (($x7 (= 0 0)))
(let (($x8 (and true true $x7)))
(let (($x66 (=> (and $x8 $x58) $x64)))
(not $x66))))))))))))
(check-sat)
