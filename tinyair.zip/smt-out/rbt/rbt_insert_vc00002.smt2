; RB insertion n=1, color=(False, None, None), path=0
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k0 () Int)
(assert
 (let (($x51 (= (or (= inserted inserted) (= inserted k0)) (or (= inserted k0) (= inserted inserted)))))
(let (($x47 (= (or (= k0 inserted) (= k0 k0)) (or (= k0 k0) (= k0 inserted)))))
(let (($x37 (< inserted k0)))
(let (($x42 (and (and true true (= 0 0) true) true (= 0 (+ 0 0)) $x37)))
(let (($x53 (and $x42 (and $x47 $x51 $x47 $x51) true)))
(let (($x55 (=> (and (and true true (= 0 0)) (and $x37 true)) $x53)))
(not $x55))))))))
(check-sat)
