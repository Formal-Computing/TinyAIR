; RB insertion n=3, color=(False, (False, None, (False, None, None)), None), path=3
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x84 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x8 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x104 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x54 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let ((?x56 (+ 0 1)))
(let (($x63 (= 0 ?x56)))
(let (($x70 (and (and true (and true true (= 0 0)) $x63 (< k0 k1)) true $x63 (< k0 k2) (< k1 k2))))
(let (($x41 (and $x70 (and $x54 $x104 $x8 $x54 $x104 $x8 $x84) true)))
(let (($x29 (=> (and $x70 (and (< inserted k2) (and (> inserted k0) $x15))) $x41)))
(not $x29))))))))))))))
(check-sat)
