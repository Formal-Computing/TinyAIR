; RB insertion n=2, color=(False, (True, None, None), None), path=0
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x86 (= (or (= inserted inserted) (= inserted k0) (= inserted k1)) (or (= inserted k0) (= inserted k1) (= inserted inserted)))))
(let (($x55 (= (or (= k1 inserted) (= k1 k0) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x50 (= (or (= k0 inserted) (= k0 k0) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x25 (< k0 k1)))
(let (($x29 (< inserted k0)))
(let (($x7 (= 0 0)))
(let (($x92 (and true true $x7)))
(let (($x52 (and $x92 $x92 (= (+ 0 1) (+ 0 1)) $x29 $x25)))
(let (($x79 (and $x52 (and $x50 $x55 $x86 $x50 $x55 $x86) true)))
(let (($x75 (and $x29 true)))
(let (($x58 (and (< inserted k1) $x75)))
(let (($x77 (and (and true true $x7 true) true (= 0 (+ 0 0)) $x25)))
(let (($x96 (=> (and $x77 $x58) $x79)))
(not $x96)))))))))))))))
(check-sat)
