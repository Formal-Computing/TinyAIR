; RB insertion n=2, color=(False, None, (True, None, None)), path=1
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x93 (= (or (= inserted k0) (= inserted inserted) (= inserted k1)) (or (= inserted k0) (= inserted k1) (= inserted inserted)))))
(let (($x21 (= (or (= k1 k0) (= k1 inserted) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x84 (= (or (= k0 k0) (= k0 inserted) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x40 (< inserted k1)))
(let (($x7 (= 0 0)))
(let (($x94 (and true true $x7)))
(let (($x88 (and $x94 $x94 (= (+ 0 1) (+ 0 1)) (< k0 inserted) $x40)))
(let (($x45 (and $x88 (and $x84 $x21 $x84 $x93 $x21 $x93) true)))
(let (($x63 (and $x40 true)))
(let (($x69 (and (> inserted k0) $x63)))
(let (($x33 (and true (and true true $x7 true) (= 0 (+ 0 0)) (< k0 k1))))
(let (($x12 (=> (and $x33 $x69) $x45)))
(not $x12))))))))))))))
(check-sat)
