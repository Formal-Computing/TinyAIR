; RB insertion n=3, color=(False, None, (True, None, (True, None, None))), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x124 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x120 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x94 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x127 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x69 (= 0 (+ 0 0))))
(let (($x133 (and true (and true true (= 0 0) true) $x69 (< k1 k2) false)))
(let (($x128 (and true $x133 $x69 (< k0 k1) (< k0 k2))))
(let (($x131 (and $x128 (and $x127 $x94 $x120 $x127 $x94 $x120 $x124) true)))
(let (($x74 (=> (and $x128 $x48) $x131)))
(not $x74))))))))))))))
(check-sat)
