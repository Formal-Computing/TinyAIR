; RB insertion n=2, color=(False, None, (True, None, None)), path=0
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x73 (= (or (= inserted inserted) (= inserted k0) (= inserted k1)) (or (= inserted k0) (= inserted k1) (= inserted inserted)))))
(let (($x41 (= (or (= k1 inserted) (= k1 k0) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x98 (= (or (= k0 inserted) (= k0 k0) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x25 (< k0 k1)))
(let (($x97 (< inserted k0)))
(let (($x95 (and true true (= 0 0) true)))
(let (($x80 (and $x95 $x95 (= (+ 0 0) (+ 0 0)) $x97 $x25)))
(let (($x85 (and $x80 (and $x98 $x41 $x73 $x98 $x41 $x73) true)))
(let (($x82 (and $x97 true)))
(let (($x33 (and true $x95 (= 0 (+ 0 0)) $x25)))
(let (($x79 (=> (and $x33 $x82) $x85)))
(not $x79)))))))))))))
(check-sat)
