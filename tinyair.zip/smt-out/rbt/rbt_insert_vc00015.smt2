; RB insertion n=2, color=(False, (False, None, None), None), path=0
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x97 (= (or (= inserted inserted) (= inserted k0) (= inserted k1)) (or (= inserted k0) (= inserted k1) (= inserted inserted)))))
(let (($x65 (= (or (= k1 inserted) (= k1 k0) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x81 (= (or (= k0 inserted) (= k0 k0) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x25 (< k0 k1)))
(let (($x66 (< inserted k1)))
(let (($x60 (< inserted k0)))
(let (($x89 (and (and true true (= 0 0) true) true (= 0 (+ 0 0)) $x60)))
(let (($x43 (and $x89 true (= 0 (+ (+ 0 0) 1)) $x66 $x25)))
(let (($x45 (and $x43 (and $x81 $x65 $x97 $x81 $x65 $x97) true)))
(let (($x52 (and $x60 true)))
(let (($x19 (and $x66 $x52)))
(let (($x68 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) $x25)))
(let (($x93 (=> (and $x68 $x19) $x45)))
(not $x93)))))))))))))))
(check-sat)
