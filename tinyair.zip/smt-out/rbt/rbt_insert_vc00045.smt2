; RB insertion n=3, color=(False, None, (False, None, (True, None, None))), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x75 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x106 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x107 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x27 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x50 (and true (and true true (= 0 0) true) (= 0 (+ 0 0)) (< k1 k2))))
(let (($x53 (and true $x50 (= 0 (+ 0 1)) (< k0 k1) (< k0 k2))))
(let (($x20 (and $x53 (and $x27 $x107 $x106 $x27 $x107 $x106 $x75) true)))
(let (($x54 (=> (and $x53 $x48) $x20)))
(not $x54)))))))))))))
(check-sat)
