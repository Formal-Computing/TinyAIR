; RB insertion n=3, color=(False, None, (False, (True, None, None), None)), path=3
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x127 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x43 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x102 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x138 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x16 (and (and true true (= 0 0) true) true (= 0 (+ 0 0)) (< k1 k2))))
(let (($x84 (and true $x16 (= 0 (+ (+ 0 0) 1)) (< k0 k1) (< k0 k2))))
(let (($x126 (and $x84 (and $x138 $x102 $x43 $x138 $x102 $x43 $x127) true)))
(let (($x76 (=> (and $x84 (and (> inserted k0) (and (< inserted k2) $x15))) $x126)))
(not $x76)))))))))))))
(check-sat)
