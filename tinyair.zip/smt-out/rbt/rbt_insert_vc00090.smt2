; RB insertion n=3, color=(False, (False, None, None), (True, None, None)), path=2
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x137 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x131 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x58 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x117 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x42 (and (and true true (= 0 0)) (and true true (= 0 0) true) (= (+ 0 1) (+ 0 0)) (< k0 k1) (< k1 k2))))
(let (($x103 (and $x42 (and $x117 $x58 $x131 $x117 $x58 $x131 $x137) true)))
(let (($x85 (=> (and $x42 (and (< inserted k1) $x48)) $x103)))
(not $x85))))))))))))
(check-sat)
