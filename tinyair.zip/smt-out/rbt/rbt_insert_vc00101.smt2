; RB insertion n=3, color=(False, (True, None, None), (False, None, None)), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x113 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x94 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x108 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x85 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x65 (and (and true true (= 0 0) true) (and true true (= 0 0)) (= (+ 0 0) (+ 0 1)) (< k0 k1) (< k1 k2))))
(let (($x143 (and $x65 (and $x85 $x108 $x94 $x85 $x108 $x94 $x113) true)))
(let (($x117 (=> (and $x65 $x15) $x143)))
(not $x117))))))))))))
(check-sat)
