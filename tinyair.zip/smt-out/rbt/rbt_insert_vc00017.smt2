; RB insertion n=2, color=(False, (False, None, None), None), path=2
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x77 (= (or (= inserted k0) (= inserted k1)) (or (= inserted k0) (= inserted k1) (= inserted inserted)))))
(let (($x86 (= (or (= k1 k0) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x79 (= (or (= k0 k0) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x68 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) (< k0 k1))))
(let (($x70 (and $x68 (and $x79 $x86 $x79 $x86 $x77) true)))
(let (($x91 (=> (and $x68 (and (< inserted k1) (= inserted k0))) $x70)))
(not $x91))))))))
(check-sat)
