; RB insertion n=2, color=(False, (True, None, None), None), path=1
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x27 (= (or (= inserted k0) (= inserted inserted) (= inserted k1)) (or (= inserted k0) (= inserted k1) (= inserted inserted)))))
(let (($x87 (= (or (= k1 k0) (= k1 inserted) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x94 (= (or (= k0 k0) (= k0 inserted) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x30 (< inserted k1)))
(let (($x7 (= 0 0)))
(let (($x92 (and true true $x7)))
(let (($x23 (and $x92 $x92 (= (+ 0 1) (+ 0 1)) (< k0 inserted) $x30)))
(let (($x85 (and $x23 (and $x94 $x87 $x94 $x27 $x87 $x27) true)))
(let (($x81 (and (> inserted k0) true)))
(let (($x89 (and $x30 $x81)))
(let (($x77 (and (and true true $x7 true) true (= 0 (+ 0 0)) (< k0 k1))))
(let (($x103 (=> (and $x77 $x89) $x85)))
(not $x103))))))))))))))
(check-sat)
