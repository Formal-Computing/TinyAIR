; RB insertion n=3, color=(False, None, (True, (True, None, None), None)), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x123 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x54 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x124 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x52 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x119 (and (and true true (= 0 0) true) true (= 0 (+ 0 0)) (< k1 k2) false)))
(let (($x94 (and true $x119 (= 0 (+ (+ 0 0) 0)) (< k0 k1) (< k0 k2))))
(let (($x38 (and $x94 (and $x52 $x124 $x54 $x52 $x124 $x54 $x123) true)))
(let (($x111 (=> (and $x94 $x48) $x38)))
(not $x111)))))))))))))
(check-sat)
