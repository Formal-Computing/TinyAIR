; RB insertion n=3, color=(False, (False, (False, None, None), None), None), path=2
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x62 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x81 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x67 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x66 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x90 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) (< k0 k1))))
(let (($x124 (and $x90 true (= 0 (+ (+ 0 1) 1)) (< k0 k2) (< k1 k2))))
(let (($x129 (and $x124 (and $x66 $x67 $x81 $x66 $x67 $x81 $x62) true)))
(let (($x57 (=> (and $x124 (and (< inserted k2) (and (< inserted k1) $x48))) $x129)))
(not $x57)))))))))))))
(check-sat)
