; RB insertion n=2, color=(False, None, (True, None, None)), path=4
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x27 (or $x48 $x15)))
(let (($x41 (= (or (= k1 k0) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x76 (= (or (= k0 k0) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x79 (and $x76 $x41 $x76 $x41 (= $x27 (or $x48 $x15 (= inserted inserted))))))
(let (($x33 (and true (and true true (= 0 0) true) (= 0 (+ 0 0)) (< k0 k1))))
(let (($x87 (and $x33 $x79 true)))
(let (($x64 (=> (and $x33 $x48) $x87)))
(not $x64)))))))))))
(check-sat)
