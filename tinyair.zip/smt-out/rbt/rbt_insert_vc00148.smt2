; RB insertion n=3, color=(False, (True, (False, None, None), None), None), path=4
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x144 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x37 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x138 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x87 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x133 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) (< k0 k1) true)))
(let (($x80 (and $x133 true (= 0 (+ (+ 0 1) 0)) (< k0 k2) (< k1 k2))))
(let (($x107 (and $x80 (and $x87 $x138 $x37 $x87 $x138 $x37 $x144) true)))
(let (($x65 (=> (and $x80 (and (< inserted k2) $x15)) $x107)))
(not $x65)))))))))))))
(check-sat)
