; RB insertion n=3, color=(False, (True, None, (False, None, None)), None), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x117 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x141 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x109 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x132 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x120 (and true (and true true (= 0 0)) (= 0 (+ 0 1)) (< k0 k1) true)))
(let (($x135 (and $x120 true (= 0 (+ 0 0)) (< k0 k2) (< k1 k2))))
(let (($x62 (and $x135 (and $x132 $x109 $x141 $x132 $x109 $x141 $x117) true)))
(let (($x43 (=> (and $x135 $x91) $x62)))
(not $x43)))))))))))))
(check-sat)
