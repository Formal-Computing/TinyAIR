; RB insertion n=3, color=(False, None, (False, (True, None, None), None)), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x129 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x67 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x123 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x87 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x16 (and (and true true (= 0 0) true) true (= 0 (+ 0 0)) (< k1 k2))))
(let (($x84 (and true $x16 (= 0 (+ (+ 0 0) 1)) (< k0 k1) (< k0 k2))))
(let (($x137 (and $x84 (and $x87 $x123 $x67 $x87 $x123 $x67 $x129) true)))
(let (($x115 (=> (and $x84 $x48) $x137)))
(not $x115)))))))))))))
(check-sat)
