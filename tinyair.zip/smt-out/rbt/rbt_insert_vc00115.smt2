; RB insertion n=3, color=(False, (False, None, (False, None, None)), None), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x14 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x80 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x103 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x114 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let ((?x56 (+ 0 1)))
(let (($x63 (= 0 ?x56)))
(let (($x70 (and (and true (and true true (= 0 0)) $x63 (< k0 k1)) true $x63 (< k0 k2) (< k1 k2))))
(let (($x22 (and $x70 (and $x114 $x103 $x80 $x114 $x103 $x80 $x14) true)))
(let (($x16 (=> (and $x70 $x91) $x22)))
(not $x16))))))))))))))
(check-sat)
