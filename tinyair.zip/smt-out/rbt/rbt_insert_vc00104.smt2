; RB insertion n=3, color=(False, (True, None, None), (True, None, None)), path=2
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x94 (or $x48 $x15 $x91)))
(let (($x80 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x33 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x143 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x110 (and $x143 $x33 $x80 $x143 $x33 $x80 (= $x94 (or $x48 $x15 $x91 (= inserted inserted))))))
(let (($x140 (and true true (= 0 0) true)))
(let (($x79 (and $x140 $x140 (= (+ 0 0) (+ 0 0)) (< k0 k1) (< k1 k2))))
(let (($x141 (and $x79 $x110 true)))
(let (($x117 (=> (and $x79 (and (< inserted k1) $x48)) $x141)))
(not $x117))))))))))))))
(check-sat)
