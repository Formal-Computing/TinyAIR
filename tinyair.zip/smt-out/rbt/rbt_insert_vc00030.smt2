; RB insertion n=3, color=(False, None, (False, None, (False, None, None))), path=5
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x117 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x119 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x111 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x66 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let ((?x65 (+ 0 1)))
(let (($x81 (= 0 ?x65)))
(let (($x20 (and true (and true (and true true (= 0 0)) $x81 (< k1 k2)) $x81 (< k0 k1) (< k0 k2))))
(let (($x115 (and $x20 (and $x66 $x111 $x119 $x66 $x111 $x119 $x117) true)))
(let (($x62 (=> (and $x20 (and (> inserted k0) $x15)) $x115)))
(not $x62))))))))))))))
(check-sat)
