; RB insertion n=2, color=(False, (False, None, None), None), path=3
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x67 (or (= inserted k0) (= inserted k1) (= inserted inserted))))
(let (($x83 (= $x67 $x67)))
(let (($x42 (or (= k1 k0) (= k1 k1) (= k1 inserted))))
(let (($x74 (= $x42 $x42)))
(let (($x16 (or (= k0 k0) (= k0 k1) (= k0 inserted))))
(let (($x71 (= $x16 $x16)))
(let (($x25 (< k0 k1)))
(let (($x7 (= 0 0)))
(let (($x92 (and true true $x7)))
(let (($x73 (and $x92 (and true true $x7 true) (= (+ 0 1) (+ 0 0)) $x25 (< k1 inserted))))
(let (($x33 (and $x73 (and $x71 $x74 $x71 $x74 $x83 $x83) true)))
(let (($x63 (and (> inserted k1) true)))
(let (($x68 (and $x92 true (= 0 (+ 0 1)) $x25)))
(let (($x93 (=> (and $x68 $x63) $x33)))
(not $x93))))))))))))))))
(check-sat)
