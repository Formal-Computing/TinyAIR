; RB insertion n=2, color=(False, (False, None, None), None), path=4
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x90 (= (or (= inserted k0) (= inserted k1)) (or (= inserted k0) (= inserted k1) (= inserted inserted)))))
(let (($x98 (= (or (= k1 k0) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x80 (= (or (= k0 k0) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x68 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) (< k0 k1))))
(let (($x84 (and $x68 (and $x80 $x98 $x80 $x98 $x90) true)))
(let (($x32 (=> (and $x68 (= inserted k1)) $x84)))
(not $x32))))))))
(check-sat)
