; RB insertion n=3, color=(False, None, (False, (False, None, None), None)), path=3
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x133 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x129 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x54 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x81 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x29 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) (< k1 k2))))
(let (($x62 (and true $x29 (= 0 (+ (+ 0 1) 1)) (< k0 k1) (< k0 k2))))
(let (($x69 (and $x62 (and $x81 $x54 $x129 $x81 $x54 $x129 $x133) true)))
(let (($x107 (=> (and $x62 (and (> inserted k0) (and (< inserted k2) $x15))) $x69)))
(not $x107)))))))))))))
(check-sat)
