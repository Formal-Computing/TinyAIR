; RB insertion n=3, color=(False, None, (False, (False, None, None), None)), path=5
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x30 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x119 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x28 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x117 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x29 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) (< k1 k2))))
(let (($x62 (and true $x29 (= 0 (+ (+ 0 1) 1)) (< k0 k1) (< k0 k2))))
(let (($x115 (and $x62 (and $x117 $x28 $x119 $x117 $x28 $x119 $x30) true)))
(let (($x67 (=> (and $x62 (and (> inserted k0) $x91)) $x115)))
(not $x67)))))))))))))
(check-sat)
