; RB insertion n=3, color=(False, (True, None, (False, None, None)), None), path=3
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x79 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x142 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x84 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x28 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x120 (and true (and true true (= 0 0)) (= 0 (+ 0 1)) (< k0 k1) true)))
(let (($x135 (and $x120 true (= 0 (+ 0 0)) (< k0 k2) (< k1 k2))))
(let (($x106 (and $x135 (and $x28 $x84 $x142 $x28 $x84 $x142 $x79) true)))
(let (($x65 (=> (and $x135 (and (< inserted k2) (and (> inserted k0) $x15))) $x106)))
(not $x65)))))))))))))
(check-sat)
