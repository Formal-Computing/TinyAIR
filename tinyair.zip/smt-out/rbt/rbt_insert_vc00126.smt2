; RB insertion n=3, color=(False, (False, None, (True, None, None)), None), path=3
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x41 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x29 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x95 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x104 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x131 (and true (and true true (= 0 0) true) (= 0 (+ 0 0)) (< k0 k1))))
(let (($x75 (and $x131 true (= 0 (+ 0 1)) (< k0 k2) (< k1 k2))))
(let (($x38 (and $x75 (and $x104 $x95 $x29 $x104 $x95 $x29 $x41) true)))
(let (($x79 (=> (and $x75 (and (< inserted k2) (and (> inserted k0) $x15))) $x38)))
(not $x79)))))))))))))
(check-sat)
