; RB insertion n=0, color=None, path=0
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(assert
 (let (($x12 (or (= inserted inserted))))
(let (($x13 (= $x12 $x12)))
(let (($x8 (and true true (= 0 0))))
(let (($x15 (and $x8 (and $x13 $x13) true)))
(let (($x17 (=> (and true true) $x15)))
(not $x17)))))))
(check-sat)
