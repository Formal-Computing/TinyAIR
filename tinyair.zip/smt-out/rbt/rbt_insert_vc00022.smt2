; RB insertion n=2, color=(False, (True, None, None), None), path=2
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x20 (or $x48 $x15)))
(let (($x13 (= (or (= k1 k0) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x26 (= (or (= k0 k0) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x32 (and $x26 $x13 $x26 $x13 (= $x20 (or $x48 $x15 (= inserted inserted))))))
(let (($x77 (and (and true true (= 0 0) true) true (= 0 (+ 0 0)) (< k0 k1))))
(let (($x88 (and $x77 $x32 true)))
(let (($x98 (=> (and $x77 (and (< inserted k1) $x48)) $x88)))
(not $x98)))))))))))
(check-sat)
