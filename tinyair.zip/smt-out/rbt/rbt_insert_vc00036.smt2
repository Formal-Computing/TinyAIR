; RB insertion n=3, color=(False, None, (True, None, (False, None, None))), path=4
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x127 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x125 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x63 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x34 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x30 (and true (and true true (= 0 0)) (= 0 (+ 0 1)) (< k1 k2) true)))
(let (($x8 (and true $x30 (= 0 (+ 0 0)) (< k0 k1) (< k0 k2))))
(let (($x128 (and $x8 (and $x34 $x63 $x125 $x34 $x63 $x125 $x127) true)))
(let (($x121 (=> (and $x8 (and (> inserted k0) (and (> inserted k1) $x91))) $x128)))
(not $x121)))))))))))))
(check-sat)
