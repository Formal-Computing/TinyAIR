; RB insertion n=3, color=(False, (False, None, (True, None, None)), None), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x58 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x46 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x55 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x20 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x131 (and true (and true true (= 0 0) true) (= 0 (+ 0 0)) (< k0 k1))))
(let (($x75 (and $x131 true (= 0 (+ 0 1)) (< k0 k2) (< k1 k2))))
(let (($x112 (and $x75 (and $x20 $x55 $x46 $x20 $x55 $x46 $x58) true)))
(let (($x135 (=> (and $x75 $x91) $x112)))
(not $x135)))))))))))))
(check-sat)
