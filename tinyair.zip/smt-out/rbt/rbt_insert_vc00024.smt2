; RB insertion n=2, color=(False, (True, None, None), None), path=4
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x89 (or $x48 $x15)))
(let (($x103 (= (or (= k1 k0) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x94 (= (or (= k0 k0) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x41 (and $x94 $x103 $x94 $x103 (= $x89 (or $x48 $x15 (= inserted inserted))))))
(let (($x77 (and (and true true (= 0 0) true) true (= 0 (+ 0 0)) (< k0 k1))))
(let (($x27 (and $x77 $x41 true)))
(let (($x87 (=> (and $x77 $x15) $x27)))
(not $x87)))))))))))
(check-sat)
