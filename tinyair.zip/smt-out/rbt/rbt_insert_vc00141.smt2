; RB insertion n=3, color=(False, (False, (False, None, None), None), None), path=4
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x50 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x23 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x65 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x41 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x90 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) (< k0 k1))))
(let (($x124 (and $x90 true (= 0 (+ (+ 0 1) 1)) (< k0 k2) (< k1 k2))))
(let (($x134 (and $x124 (and $x41 $x65 $x23 $x41 $x65 $x23 $x50) true)))
(let (($x37 (=> (and $x124 (and (< inserted k2) $x15)) $x134)))
(not $x37)))))))))))))
(check-sat)
