; RB insertion n=3, color=(False, (True, (False, None, None), None), None), path=2
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x46 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x130 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x94 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x120 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x133 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) (< k0 k1) true)))
(let (($x80 (and $x133 true (= 0 (+ (+ 0 1) 0)) (< k0 k2) (< k1 k2))))
(let (($x141 (and $x80 (and $x120 $x94 $x130 $x120 $x94 $x130 $x46) true)))
(let (($x56 (=> (and $x80 (and (< inserted k2) (and (< inserted k1) $x48))) $x141)))
(not $x56)))))))))))))
(check-sat)
