; RB insertion n=3, color=(False, (True, None, None), (True, None, None)), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x139 (or $x48 $x15 $x91)))
(let (($x80 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x130 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x122 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x138 (and $x122 $x130 $x80 $x122 $x130 $x80 (= $x139 (or $x48 $x15 $x91 (= inserted inserted))))))
(let (($x140 (and true true (= 0 0) true)))
(let (($x79 (and $x140 $x140 (= (+ 0 0) (+ 0 0)) (< k0 k1) (< k1 k2))))
(let (($x117 (and $x79 $x138 true)))
(let (($x126 (=> (and $x79 $x15) $x117)))
(not $x126))))))))))))))
(check-sat)
