; RB insertion n=3, color=(False, (True, None, (True, None, None)), None), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x81 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x53 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x33 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x26 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let ((?x37 (+ 0 0)))
(let (($x101 (= 0 ?x37)))
(let (($x93 (and true (and true true (= 0 0) true) $x101 (< k0 k1) false)))
(let (($x64 (and $x93 true $x101 (< k0 k2) (< k1 k2))))
(let (($x73 (and $x64 (and $x26 $x33 $x53 $x26 $x33 $x53 $x81) true)))
(let (($x84 (=> (and $x64 $x91) $x73)))
(not $x84)))))))))))))))
(check-sat)
