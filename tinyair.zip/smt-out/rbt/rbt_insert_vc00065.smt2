; RB insertion n=3, color=(False, None, (True, (False, None, None), None)), path=5
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x79 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x66 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x62 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x56 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x8 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) (< k1 k2) true)))
(let (($x121 (and true $x8 (= 0 (+ (+ 0 1) 0)) (< k0 k1) (< k0 k2))))
(let (($x69 (and $x121 (and $x56 $x62 $x66 $x56 $x62 $x66 $x79) true)))
(let (($x124 (=> (and $x121 (and (> inserted k0) $x91)) $x69)))
(not $x124)))))))))))))
(check-sat)
