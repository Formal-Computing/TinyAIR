; RB insertion n=3, color=(False, (False, (True, None, None), None), None), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x14 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x87 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x20 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x132 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x34 (and (and true true (= 0 0) true) true (= 0 (+ 0 0)) (< k0 k1))))
(let (($x54 (and $x34 true (= 0 (+ (+ 0 0) 1)) (< k0 k2) (< k1 k2))))
(let (($x147 (and $x54 (and $x132 $x20 $x87 $x132 $x20 $x87 $x14) true)))
(let (($x98 (=> (and $x54 $x91) $x147)))
(not $x98)))))))))))))
(check-sat)
