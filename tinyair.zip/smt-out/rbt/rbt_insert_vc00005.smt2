; RB insertion n=2, color=(False, None, (False, None, None)), path=0
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x68 (= (or (= inserted inserted) (= inserted k0) (= inserted k1)) (or (= inserted k0) (= inserted k1) (= inserted inserted)))))
(let (($x17 (= (or (= k1 inserted) (= k1 k0) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x53 (= (or (= k0 inserted) (= k0 k0) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x25 (< k0 k1)))
(let (($x30 (< inserted k0)))
(let (($x7 (= 0 0)))
(let (($x8 (and true true $x7)))
(let (($x56 (and (and true true $x7 true) $x8 (= (+ 0 0) (+ 0 1)) $x30 $x25)))
(let (($x70 (and $x56 (and $x53 $x17 $x68 $x53 $x17 $x68) true)))
(let (($x13 (and $x30 true)))
(let (($x52 (and true $x8 (= 0 (+ 0 1)) $x25)))
(let (($x72 (=> (and $x52 $x13) $x70)))
(not $x72))))))))))))))
(check-sat)
