; RB insertion n=3, color=(False, (False, (False, None, None), None), None), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x28 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x130 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x136 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x69 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x90 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) (< k0 k1))))
(let (($x124 (and $x90 true (= 0 (+ (+ 0 1) 1)) (< k0 k2) (< k1 k2))))
(let (($x56 (and $x124 (and $x69 $x136 $x130 $x69 $x136 $x130 $x28) true)))
(let (($x135 (=> (and $x124 $x91) $x56)))
(not $x135)))))))))))))
(check-sat)
