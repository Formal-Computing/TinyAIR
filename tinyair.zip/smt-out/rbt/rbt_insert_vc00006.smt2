; RB insertion n=2, color=(False, None, (False, None, None)), path=1
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x90 (= (or (= inserted k0) (= inserted inserted) (= inserted k1)) (or (= inserted k0) (= inserted k1) (= inserted inserted)))))
(let (($x88 (= (or (= k1 k0) (= k1 inserted) (= k1 k1)) (or (= k1 k0) (= k1 k1) (= k1 inserted)))))
(let (($x86 (= (or (= k0 k0) (= k0 inserted) (= k0 k1)) (or (= k0 k0) (= k0 k1) (= k0 inserted)))))
(let (($x25 (< k0 k1)))
(let (($x76 (< inserted k1)))
(let (($x81 (and (and true true (= 0 0) true) true (= 0 (+ 0 0)) $x76)))
(let (($x84 (and true $x81 (= 0 (+ (+ 0 0) 1)) (< k0 inserted) $x25)))
(let (($x92 (and $x84 (and $x86 $x88 $x86 $x90 $x88 $x90) true)))
(let (($x77 (and $x76 true)))
(let (($x79 (and (> inserted k0) $x77)))
(let (($x52 (and true (and true true (= 0 0)) (= 0 (+ 0 1)) $x25)))
(let (($x94 (=> (and $x52 $x79) $x92)))
(not $x94))))))))))))))
(check-sat)
