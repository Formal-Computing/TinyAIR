; RB insertion n=3, color=(False, (False, None, None), (False, None, None)), path=6
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x87 (or $x48 $x15 $x91)))
(let (($x58 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x56 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x65 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x85 (and $x65 $x56 $x58 $x65 $x56 $x58 (= $x87 (or $x48 $x15 $x91 (= inserted inserted))))))
(let (($x130 (and true true (= 0 0))))
(let (($x12 (and $x130 $x130 (= (+ 0 1) (+ 0 1)) (< k0 k1) (< k1 k2))))
(let (($x54 (and $x12 $x85 true)))
(let (($x103 (=> (and $x12 $x15) $x54)))
(not $x103))))))))))))))
(check-sat)
