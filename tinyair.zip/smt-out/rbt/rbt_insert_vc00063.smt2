; RB insertion n=3, color=(False, None, (True, (False, None, None), None)), path=3
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x43 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x60 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x109 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x131 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x8 (and (and true true (= 0 0)) true (= 0 (+ 0 1)) (< k1 k2) true)))
(let (($x121 (and true $x8 (= 0 (+ (+ 0 1) 0)) (< k0 k1) (< k0 k2))))
(let (($x29 (and $x121 (and $x131 $x109 $x60 $x131 $x109 $x60 $x43) true)))
(let (($x127 (=> (and $x121 (and (> inserted k0) (and (< inserted k2) $x15))) $x29)))
(not $x127)))))))))))))
(check-sat)
