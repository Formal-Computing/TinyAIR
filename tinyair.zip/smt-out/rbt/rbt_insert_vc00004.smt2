; RB insertion n=1, color=(False, None, None), path=2
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k0 () Int)
(assert
 (let (($x34 (= (or (= inserted k0)) (or (= inserted k0) (= inserted inserted)))))
(let (($x32 (= (or (= k0 k0)) (or (= k0 k0) (= k0 inserted)))))
(let (($x8 (and true true (= 0 0))))
(let (($x26 (and $x8 (and $x32 $x32 $x34) true)))
(let (($x18 (=> (and $x8 (= inserted k0)) $x26)))
(not $x18)))))))
(check-sat)
