; RB insertion n=3, color=(False, (True, None, None), (False, None, None)), path=2
; BOUNDED shape/color proof obligation
; benchmark generated from python API
(set-info :status unknown)
(declare-fun inserted () Int)
(declare-fun k2 () Int)
(declare-fun k1 () Int)
(declare-fun k0 () Int)
(assert
 (let (($x91 (= inserted k2)))
(let (($x15 (= inserted k1)))
(let (($x48 (= inserted k0)))
(let (($x85 (= (or $x48 $x15 $x91) (or $x48 $x15 $x91 (= inserted inserted)))))
(let (($x93 (= (or (= k2 k0) (= k2 k1) (= k2 k2)) (or (= k2 k0) (= k2 k1) (= k2 k2) (= k2 inserted)))))
(let (($x66 (= (or (= k1 k0) (= k1 k1) (= k1 k2)) (or (= k1 k0) (= k1 k1) (= k1 k2) (= k1 inserted)))))
(let (($x34 (= (or (= k0 k0) (= k0 k1) (= k0 k2)) (or (= k0 k0) (= k0 k1) (= k0 k2) (= k0 inserted)))))
(let (($x65 (and (and true true (= 0 0) true) (and true true (= 0 0)) (= (+ 0 0) (+ 0 1)) (< k0 k1) (< k1 k2))))
(let (($x143 (and $x65 (and $x34 $x66 $x93 $x34 $x66 $x93 $x85) true)))
(let (($x131 (=> (and $x65 (and (< inserted k1) $x48)) $x143)))
(not $x131))))))))))))
(check-sat)
